package com.nova.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts background wake-word listening after a reboot, if the user had it enabled. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("nova", Context.MODE_PRIVATE)
        if (prefs.getBoolean(NovaBackgroundService.PREF_ALWAYS_LISTEN, false)) {
            val serviceIntent = Intent(context, NovaBackgroundService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        }
    }
}
