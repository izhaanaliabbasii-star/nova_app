package com.nova.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/** Looks up a phone number from a contact's display name (best fuzzy match). */
object ContactLookup {

    fun findNumber(ctx: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return null  // no crash — caller falls back to a graceful message
        }

        return try {
            queryContacts(ctx, name)
        } catch (e: SecurityException) {
            null
        } catch (e: Exception) {
            null
        }
    }

    private fun queryContacts(ctx: Context, name: String): String? {
        val resolver = ctx.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, null
        ) ?: return null

        var bestNumber: String? = null
        var bestScore = 0
        val needle = name.trim().lowercase()

        cursor.use { c ->
            val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext()) {
                val contactName = c.getString(nameIdx)?.lowercase() ?: continue
                val number = c.getString(numberIdx) ?: continue
                val score = when {
                    contactName == needle -> 100
                    contactName.startsWith(needle) -> 80
                    contactName.contains(needle) -> 60
                    else -> 0
                }
                if (score > bestScore) { bestScore = score; bestNumber = number }
            }
        }
        return bestNumber
    }
}
