package com.nova.assistant

import android.animation.ObjectAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Four-stage boot sequence, ported from Jarvis's desktop "cinematic" setup:
 *   1. System scan (typewriter log)
 *   2. Choose AI provider (Gemini card)
 *   3. Paste key -> fake "authenticating" bar animation -> "Hello, I'm Nova"
 *   4. "Establishing Neural Link" -> modules power up one by one -> done
 * Only runs once; MainActivity's own fields handle changing the key later.
 */
class OnboardingActivity : AppCompatActivity() {

    companion object {
        const val PREF_ONBOARDED = "onboarding_done"
    }

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())
    private var authStarted = false

    private val scanLines = listOf(
        "Scanning device...",
        "✓ Android device detected",
        "✓ Microphone found",
        "✓ Network online",
        "Looking for an AI provider...",
        "✕ No provider configured yet",
        "One key gets me thinking."
    )

    private val authBars = listOf("█", "████", "███████", "███████████", "███████████████")

    private val ignitionModules = listOf(
        "MEMORY       ███████",
        "VOICE        ███████",
        "VISION       ███████",
        "AUTOMATION   ███████",
        "REASONING    ███████"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("nova", MODE_PRIVATE)

        if (prefs.getBoolean(PREF_ONBOARDED, false)) {
            goToMain()
            return
        }

        setContentView(R.layout.activity_onboarding)

        // ---------- Stage 1: scan ----------
        val stage1: View = findViewById(R.id.stage1)
        val stage2: View = findViewById(R.id.stage2)
        val stage3: View = findViewById(R.id.stage3)
        val stage4: View = findViewById(R.id.stage4)
        val scanLog: TextView = findViewById(R.id.scanLog)

        runScanSequence(scanLog) { switchStage(stage1, stage2) }

        // ---------- Stage 2: choose provider ----------
        findViewById<LinearLayout>(R.id.geminiCard).setOnClickListener {
            switchStage(stage2, stage3)
        }

        // ---------- Stage 3: paste key + fake auth ----------
        val keyInput: EditText = findViewById(R.id.onboardGeminiKey)
        val authStatus: TextView = findViewById(R.id.authStatus)
        val stage3Sub: TextView = findViewById(R.id.stage3Sub)
        val stage3Title: TextView = findViewById(R.id.stage3Title)
        val authBox: View = findViewById(R.id.authBox)
        val helloPanel: View = findViewById(R.id.helloPanel)
        val getKeyLink: TextView = findViewById(R.id.getKeyLink)
        val launchButton: Button = findViewById(R.id.launchButton)
        val skipLink: TextView = findViewById(R.id.skipSetupLink)
        val skipLinkEarly: TextView = findViewById(R.id.skipSetupLinkEarly)

        getKeyLink.setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }

        keyInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if ((s?.length ?: 0) > 10 && !authStarted) {
                    authStarted = true
                    keyInput.isEnabled = false
                    stage3Sub.text = "Authenticating..."
                    runAuthSequence(authStatus) {
                        authStatus.text = "✓ Identity Verified\nGemini ready\nLatency 87 ms"
                        stage3Title.setTextColor(0xFF00C853.toInt())
                        handler.postDelayed({
                            authBox.visibility = View.GONE
                            helloPanel.visibility = View.VISIBLE
                            ObjectAnimator.ofFloat(helloPanel, "alpha", 0f, 1f).setDuration(500).start()
                        }, 1200)
                    }
                }
            }
        })

        launchButton.setOnClickListener {
            prefs.edit().putString("gemini_key", keyInput.text.toString().trim()).apply()
            switchStage(stage3, stage4)
            runIgnitionSequence()
        }

        skipLink.setOnClickListener {
            prefs.edit().putBoolean(PREF_ONBOARDED, true).apply()
            goToMain()
        }
        skipLinkEarly.setOnClickListener {
            prefs.edit().putBoolean(PREF_ONBOARDED, true).apply()
            goToMain()
        }
    }

    private fun switchStage(from: View, to: View) {
        from.visibility = View.GONE
        to.visibility = View.VISIBLE
        to.alpha = 0f
        ObjectAnimator.ofFloat(to, "alpha", 0f, 1f).setDuration(400).start()
    }

    /** Reveals scan lines one at a time, typewriter-log style. */
    private fun runScanSequence(scanLog: TextView, onDone: () -> Unit) {
        var index = 0
        val builder = StringBuilder()
        fun tick() {
            if (index >= scanLines.size) { onDone(); return }
            if (builder.isNotEmpty()) builder.append("\n")
            builder.append(scanLines[index])
            scanLog.text = builder.toString()
            index++
            handler.postDelayed({ tick() }, 750)
        }
        handler.postDelayed({ tick() }, 500)
    }

    /** Fake "authenticating" bar-fill animation — purely cosmetic, no real network check. */
    private fun runAuthSequence(authStatus: TextView, onDone: () -> Unit) {
        var step = 0
        fun tick() {
            if (step >= authBars.size) { onDone(); return }
            authStatus.text = authBars[step]
            step++
            handler.postDelayed({ tick() }, 200)
        }
        tick()
    }

    /** Modules "powering up" one by one, then hands off to MainActivity. */
    private fun runIgnitionSequence() {
        val title: TextView = findViewById(R.id.ignitionTitle)
        val log: TextView = findViewById(R.id.ignitionLog)
        var step = 0
        val builder = StringBuilder()
        fun tick() {
            if (step >= ignitionModules.size) {
                title.text = "Neural Link Established."
                title.setTextColor(0xFF00C853.toInt())
                handler.postDelayed({
                    prefs.edit().putBoolean(PREF_ONBOARDED, true).apply()
                    goToMain()
                }, 900)
                return
            }
            if (builder.isNotEmpty()) builder.append("\n")
            builder.append(ignitionModules[step])
            log.text = builder.toString()
            step++
            handler.postDelayed({ tick() }, 500)
        }
        handler.postDelayed({ tick() }, 400)
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
