package com.nova.assistant

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/**
 * "battery" -> percentage, charging status, temperature, and Android's own
 * health flag. NOTE: Android does NOT expose a numeric "battery health %"
 * like iOS does (max-capacity vs original) — that number simply isn't in
 * the public API on stock Android. This reports everything that IS
 * available: charge %, temperature, and the OS health status (Good /
 * Overheat / Cold / Over voltage / Dead / Unknown).
 */
object BatteryMonitor {

    fun report(ctx: Context): String {
        val intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Couldn't read the battery right now."

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val tempC = if (tempTenths >= 0) tempTenths / 10.0 else null

        val health = when (intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "overheating"
            BatteryManager.BATTERY_HEALTH_COLD -> "too cold"
            BatteryManager.BATTERY_HEALTH_DEAD -> "dead — time for a new battery"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "over voltage — get it checked"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "reporting a fault — get it checked"
            else -> "unknown"
        }

        val parts = mutableListOf<String>()
        if (pct >= 0) parts.add("$pct%")
        parts.add(if (charging) "charging" else "not charging")
        if (tempC != null) parts.add("${tempC}°C")
        parts.add("health: $health")

        return "Battery is " + parts.joinToString(", ") + "."
    }
}
