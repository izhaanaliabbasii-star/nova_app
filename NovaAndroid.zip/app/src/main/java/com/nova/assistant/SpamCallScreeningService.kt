package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.telecom.Call
import android.telecom.CallScreeningService

/**
 * Flags incoming calls from numbers NOT in your contacts as "possible spam"
 * with a notification. This is a heuristic (unknown number = flagged), NOT
 * a real spam database like Truecaller — building an actual spam database
 * would need a paid third-party API this app doesn't have. It does not
 * block calls automatically; it just warns you before you pick up.
 *
 * To activate: Settings > Apps > Default apps > Caller ID & spam protection
 * (or Nova's "Enable spam call flagging" button, which opens that same
 * request) -> select Nova. Android only allows ONE app to hold this role.
 */
class SpamCallScreeningService : CallScreeningService() {

    companion object {
        private const val CHANNEL_ID = "nova_spam"
    }

    override fun onScreenCall(callDetails: Call.Details) {
        val number = callDetails.handle?.schemeSpecificPart

        // never block/screen anything if we can't even read the number
        if (number.isNullOrBlank()) {
            respondToCall(callDetails, CallResponse.Builder().build())
            return
        }

        val knownContact = ContactLookup.findNumber(this, number) != null ||
            isNumberSaved(number)

        // Always allow the call through — Nova only warns, never silently blocks,
        // since a heuristic this simple ("not in contacts") has real false positives
        // (delivery drivers, new numbers, doctors' offices, etc).
        respondToCall(callDetails, CallResponse.Builder().build())

        if (!knownContact) {
            notifyPossibleSpam(number)
        }
    }

    private fun isNumberSaved(number: String): Boolean {
        // ContactLookup matches by name, not number -> do a lightweight reverse check
        return try {
            val cursor = contentResolver.query(
                android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI
                    .buildUpon().appendPath(number).build(),
                arrayOf(android.provider.ContactsContract.PhoneLookup.DISPLAY_NAME),
                null, null, null
            )
            val found = cursor?.use { it.moveToFirst() } ?: false
            found
        } catch (e: Exception) {
            true // if we can't check, don't falsely flag as spam
        }
    }

    private fun notifyPossibleSpam(number: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Possible spam calls", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Possible spam call")
            .setContentText("Incoming call from $number — not in your contacts.")
            .setSmallIcon(R.drawable.ic_launcher)
            .setAutoCancel(true)
            .build()
        nm.notify(number.hashCode(), notification)
    }
}
