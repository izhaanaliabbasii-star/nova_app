package com.nova.assistant

import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.Settings
import java.util.Calendar
import java.util.Locale
import java.util.regex.Pattern

/**
 * Grab-bag of small Android-native actions that map to individual Jarvis
 * (desktop) features: flashlight, Do Not Disturb, brightness, calendar
 * events, web search, and Spotify search-and-play.
 */
object SystemActions {

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()

        if (t.contains("flashlight") || t.contains("torch")) return toggleFlashlight(ctx, t.contains("on") && !t.contains("off"))
        if (t.contains("do not disturb") || t.contains("dnd")) return toggleDnd(ctx, t.contains("on") && !t.contains("off"))
        if (t.contains("brightness")) return setBrightness(ctx, t)
        if (t.startsWith("add event") || t.startsWith("schedule") || t.startsWith("add to calendar")) return addCalendarEvent(ctx, raw)
        if (t.startsWith("search for") || t.startsWith("google") || t.startsWith("look up")) return webSearch(ctx, t)
        if (t.contains("spotify") || t.contains("play song") || t.startsWith("play ") && t.contains(" on spotify")) return spotifyPlay(ctx, raw)
        if (t.contains("battery")) return BatteryMonitor.report(ctx)
        if (t.startsWith("find my") || t.startsWith("find file") || t.startsWith("find a file")
            || (t.startsWith("find") && t.contains("pdf"))) {
            return FileFinder.find(ctx, raw)
        }
        if (t.startsWith("log ")) return HabitTracker.log(ctx, raw.substring(4).trim())
        if (t.startsWith("how many") && t.contains("today")) {
            val habit = t.removePrefix("how many").substringBefore("today").trim()
            return HabitTracker.count(ctx, habit)
        }
        if (t.startsWith("remember")) return MemoryManager.remember(ctx, raw.substringAfter("remember").trim())
        if (t.startsWith("what do you remember") || t.startsWith("do you remember")) {
            return MemoryManager.recall(ctx, raw)
        }
        if (t == "what do you know" || t == "list everything you remember") return MemoryManager.listAll(ctx)
        if (t.contains("forget everything")) return MemoryManager.forgetAll(ctx)

        return null
    }

    // ---------------- Flashlight ----------------
    private var torchOn = false
    private fun toggleFlashlight(ctx: Context, turnOn: Boolean): String {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val camId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return "This device doesn't seem to have a flashlight."
            cm.setTorchMode(camId, turnOn)
            torchOn = turnOn
            if (turnOn) "Flashlight on." else "Flashlight off."
        } catch (e: Exception) {
            "Couldn't control the flashlight: ${e.message}"
        }
    }

    // ---------------- Do Not Disturb ----------------
    private fun toggleDnd(ctx: Context, turnOn: Boolean): String {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            ctx.startActivity(
                Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "I need Do Not Disturb permission first — grant it on the screen that just opened, then try again."
        }
        nm.setInterruptionFilter(
            if (turnOn) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return if (turnOn) "Do Not Disturb on." else "Do Not Disturb off."
    }

    // ---------------- Brightness ----------------
    private fun setBrightness(ctx: Context, t: String): String {
        if (!Settings.System.canWrite(ctx)) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "I need display-settings permission first — grant it on the screen that just opened, then try again."
        }
        return try {
            val current = Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
            val percentMatch = Pattern.compile("(\\d{1,3})\\s*%?").matcher(t)
            val newValue = when {
                t.contains("up") || t.contains("increase") || t.contains("brighter") ->
                    (current + 51).coerceAtMost(255)
                t.contains("down") || t.contains("decrease") || t.contains("dim") || t.contains("lower") ->
                    (current - 51).coerceAtLeast(10)
                percentMatch.find() -> (percentMatch.group(1)!!.toInt() * 255 / 100).coerceIn(0, 255)
                else -> return openBrightnessSettings(ctx)
            }
            Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, newValue)
            "Brightness set to ${newValue * 100 / 255}%."
        } catch (e: Exception) {
            "Couldn't change brightness: ${e.message}"
        }
    }

    private fun openBrightnessSettings(ctx: Context): String {
        return try {
            ctx.startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Say \"brightness up\", \"brightness down\", or \"brightness 50%\" — or opening display settings now."
        } catch (e: Exception) {
            "Couldn't open brightness settings."
        }
    }

    // ---------------- Calendar ----------------
    private fun addCalendarEvent(ctx: Context, raw: String): String {
        // "add event <title> at <H(:MM)>(am/pm)" — best-effort, opens the
        // calendar app's own "new event" screen pre-filled so the user
        // confirms details rather than Nova silently booking things.
        val title = raw.replace(Regex("(?i)add event|add to calendar|schedule"), "").trim()
        val cal = Calendar.getInstance()
        val timeMatch = Pattern.compile("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", Pattern.CASE_INSENSITIVE).matcher(title)
        if (timeMatch.find()) {
            var hour = timeMatch.group(1)?.toIntOrNull() ?: cal.get(Calendar.HOUR_OF_DAY)
            val minute = timeMatch.group(2)?.toIntOrNull() ?: 0
            val ampm = timeMatch.group(3)?.lowercase()
            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
        }
        val intent = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI).apply {
            putExtra(CalendarContract.Events.TITLE, title.ifBlank { "New event" })
            putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, cal.timeInMillis)
            putExtra(CalendarContract.EXTRA_EVENT_END_TIME, cal.timeInMillis + 60 * 60 * 1000)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            "Opening your calendar app to confirm the event."
        } catch (e: ActivityNotFoundException) {
            "No calendar app found to add the event."
        }
    }

    // ---------------- Web search ----------------
    private fun webSearch(ctx: Context, t: String): String {
        val query = t.removePrefix("search for").removePrefix("google").removePrefix("look up").trim()
        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            "Searching for $query."
        } catch (e: ActivityNotFoundException) {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Searching for $query in the browser."
        }
    }

    // ---------------- Spotify ----------------
    private fun spotifyPlay(ctx: Context, raw: String): String {
        val query = raw.lowercase(Locale.ROOT)
            .replace("play", "").replace("on spotify", "").replace("spotify", "").trim()
            .ifBlank { "your playlist" }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + Uri.encode(query)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Searching Spotify for $query."
        } catch (e: ActivityNotFoundException) {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/" + Uri.encode(query)))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                "Spotify app not found, opening it in the browser."
            } catch (e2: Exception) {
                "Couldn't open Spotify."
            }
        }
    }
}
